class Reminder:
    def __init__(self, date, amount, description):
        self.date = date
        self.amount = amount
        self.description = description

    def myfunc(self):
        print(self.date)
        print(self.amount)
        print(self.description)


t1 = Reminder("4/5/2020", -40.56, "Phone")
t2 = Reminder("4/7/2020", -17.54, "Gym")
t3 = Reminder("4/21/2020", -17.54, "Gym")


Reminders=[t1, t2, t3]