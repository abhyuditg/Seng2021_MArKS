class Transact:
    def __init__(self, date, amount, description):
        self.date = date
        self.amount = amount
        self.description = description

    def myfunc(self):
        print(self.date)
        print(self.amount)
        print(self.description)


t1 = Transact("1/4/2019", 400, "Work")
t2 = Transact("5/4/2019", -40.56, "Phone")
t3 = Transact("7/4/2019", -17.54, "Gym")
t4 = Transact("21/4/2019", -17.54, "Gym")
t5 = Transact("14/4/2019", 400, "Work")
t6 = Transact("16/4/2019", -14.53, "Food")
t7 = Transact("22/4/2019", -9.99, "Food")
t8 = Transact("22/4/2019", -15.00, "Entertainment")
t9 = Transact("25/4/2019", -30.00, "Shopping")
t10 = Transact("28/4/2019", -27.05, "Food")

t11 = Transact("1/5/2019", 400, "Work")
t12 = Transact("1/5/2019", -21, "Food")
t13 = Transact("5/5/2019", -40.56, "Phone")
t14 = Transact("5/5/2019", -17.54, "Gym")
t15 = Transact("19/5/2019", -17.54, "Gym")
t16 = Transact("14/5/2019", 400, "Work")
t17 = Transact("14/5/2019", -20.44, "Entertainment")
t18 = Transact("14/5/2019", -12.30, "Food")
t19 = Transact("20/5/2019", -22.88, "Food")
t20 = Transact("22/5/2019", -13.00, "Shopping")
t21 = Transact("22/5/2019", -12.00, "Shopping")
t22 = Transact("22/5/2019", -5.00, "Shopping")
t23 = Transact("28/5/2019", -200, "Travel")
t24 = Transact("28/5/2019", -167, "Travel")
t25 = Transact("30/5/2019", -15.67, "Food")

t26 = Transact("1/6/2019", 400, "Work")
t27 = Transact("2/6/2019", -17.54, "Gym")
t28 = Transact("5/6/2019", -40.56, "Phone")
t29 = Transact("7/6/2019", -32.00, "Food")
t30 = Transact("14/6/2019", 400, "Work")
t31 = Transact("16/6/2019", -17.54, "Gym")
t32 = Transact("17/6/2019", -12.00, "Food")
t33 = Transact("24/6/2019", -13.44, "Food")
t34 = Transact("24/6/2019", -30.00, "Gift")

t35 = Transact("1/7/2019", 400, "Work")
t36 = Transact("5/7/2019", -40.56, "Phone")
t37 = Transact("5/7/2019", -10.99, "Food")
t38 = Transact("7/7/2019", -17.54, "Gym")
t39 = Transact("10/7/2019", -13.44, "Food")
t40 = Transact("14/7/2019", 400, "Work")
t41 = Transact("21/7/2019", -17.54, "Gym")
t42 = Transact("22/7/2019", -23.88, "Food")
t43 = Transact("26/7/2019", -110.64, "Shopping")
t44 = Transact("27/7/2019", -30.00, "Entertainment")
t45 = Transact("30/7/2019", -17.54, "Gym")

t46 = Transact("1/8/2019", 400, "Work")
t47 = Transact("1/8/2019", -22, "Food")
t48 = Transact("5/8/2019", -40.56, "Phone")
t49 = Transact("13/8/2019", -17.54, "Gym")
t50 = Transact("14/8/2019", 400, "Work")
t51 = Transact("14/8/2019", -14.30, "Food")
t52 = Transact("14/8/2019", -30.00, "Entertainment")
t53 = Transact("22/8/2019", -15, "Entertainment")
t54 = Transact("26/8/2019", -22.88, "Food")
t55 = Transact("27/8/2019", -17.54, "Gym")
t56 = Transact("28/8/2019", -399, "Travel")
t57 = Transact("28/8/2019", -155, "Travel")
t58 = Transact("30/8/2019", -18.67, "Food")

t59 = Transact("1/9/2019", 400, "Work")
t60 = Transact("3/9/2019", -11.00, "Food")
t61 = Transact("5/9/2019", -40.56, "Phone")
t62 = Transact("10/9/2019", -17.54, "Gym")
t63 = Transact("14/9/2019", 400, "Work")
t64 = Transact("16/9/2019", -13.90, "Food")
t65 = Transact("20/9/2019", -42.00, "Shopping")
t66 = Transact("20/9/2019", -22.88, "Gift")
t67 = Transact("24/9/2019", -8.00, "Food")
t68 = Transact("24/9/2019", -17.54, "Gym")
t69 = Transact("29/9/2019", -16.44, "Food")

t70 = Transact("1/10/2019", 400, "Work")
t71 = Transact("1/10/2019", -21.00, "Food")
t72 = Transact("5/10/2019", -40.56, "Phone")
t73 = Transact("8/10/2019", -17.54, "Gym")
t74 = Transact("10/10/2019", -29.88, "Food")
t75 = Transact("14/10/2019", 400, "Work")
t76 = Transact("14/10/2019", -15.30, "Food")
t77 = Transact("22/10/2019", -17.54, "Gym")

t78 = Transact("1/11/2019", 400, "Work")
t79 = Transact("5/11/2019", -40.56, "Phone")
t80 = Transact("5/11/2019", -15.99, "Food")
t81 = Transact("1/11/2019", 400, "Work")
t82 = Transact("10/11/2019", -17.04, "Food")
t83 = Transact("22/11/2019", -25.18, "Food")
t84 = Transact("22/11/2019", -20.00, "Gift")
t85 = Transact("22/11/2019", -31.00, "Gift")
t86 = Transact("22/11/2019", -28.36, "Gift")
t87 = Transact("22/11/2019", -45.30, "Gift")
t88 = Transact("22/11/2019", -22.99, "Gift")
t89 = Transact("22/11/2019", -52.00, "Gift")
t90 = Transact("30/11/2019", -500.00, "Travel")
t91 = Transact("30/11/2019", -399.87, "Travel")

t92 = Transact("1/12/2019", 400, "Work")
t93 = Transact("5/12/2019", -40.56, "Phone")
t94 = Transact("5/12/2019", -17.99, "Food")
t95 = Transact("5/12/2019", -60.00, "Gift")
t96 = Transact("5/12/2019", -17.04, "Gift")
t97 = Transact("9/12/2019", -15.99, "Food")
t98 = Transact("10/12/2019", -15.44, "Gift")
t99 = Transact("10/12/2019", -13.44, "Food")
t100 = Transact("10/12/2019", -21.00, "Gift")
t101 = Transact("14/12/2019", 400, "Work")
t102 = Transact("16/12/2019", -17.44, "Food")
t103 = Transact("22/12/2019", -23.88, "Food")
t104 = Transact("25/12/2019", -24.00, "Entertainment")
t105 = Transact("27/12/2019", -22.88, "Food")
t106 = Transact("30/12/2019", -30.00, "Entertainment")

t107 = Transact("1/1/2020", 400, "Work")
t108 = Transact("5/1/2020", -40.56, "Phone")
t109 = Transact("8/1/2020", -14.53, "Food")
t110 = Transact("10/1/2020", -17.54, "Gym")
t111 = Transact("14/1/2020", 400, "Work")
t112 = Transact("22/1/2020", -9.99, "Food")
t113 = Transact("24/1/2020", -17.54, "Gym")
t114 = Transact("24/1/2020", -27.54, "Food")

t115 = Transact("1/2/2020", 400, "Work")
t116 = Transact("5/2/2020", -40.56, "Phone")
t117 = Transact("6/2/2020", -10.09, "Shopping")
t118 = Transact("6/2/2020", -39.49, "Shopping")
t119 = Transact("6/2/2020", -29.94, "Shopping")
t120 = Transact("6/2/2020", -19.99, "Food")
t120 = Transact("9/2/2020", -12.44, "Food")
t121 = Transact("9/2/2020", -17.54, "Gym")
t122 = Transact("14/2/2020", 400, "Work")
t123 = Transact("22/2/2020", -27.88, "Food")
t124 = Transact("23/2/2020", -17.54, "Gym")

t125 = Transact("1/3/2020", 400, "Work")
t126 = Transact("5/3/2020", -40.56, "Phone")
t127 = Transact("8/3/2020", -21.00, "Food")
t128 = Transact("14/3/2020", 400.00, "Work")

t129 = Transact("1/4/2020", 300, "Work")
t130 = Transact("4/4/2020", 300, "Travel")

transaction_history = [t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21,
                       t22, t23, t24, t25, t26, t27, t28, t29, t30, t31, t32, t33, t34, t35, t36, t37, t38, t39, t40,
                       t41, t42, t43, t44, t45, t46, t47, t48, t49, t50, t51, t52, t53, t54, t55, t56, t57, t58, t59,
                       t60, t61, t62, t63, t64, t65, t66, t67, t68, t69, t70, t71, t72, t73, t74, t75, t76, t77, t78,
                       t79, t80, t81, t82, t83, t84, t85, t86, t87, t88, t89, t90, t91, t92, t93, t94, t95, t96, t97,
                       t98, t99, t100, t101, t102, t103, t104, t105, t106, t107, t108, t109, t110, t111, t112, t113,
                       t114, t115, t116, t117, t118, t119, t120, t121, t122, t123, t124, t125, t126, t127, t128, t129, t130]





