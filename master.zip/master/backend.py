from datetime import datetime, date
from collections import defaultdict
import dateutil.relativedelta
import calendar
import sqlite3
from database import *
import json

class Transact:
    def __init__(self, date, amount, description):
        self.date = date
        self.amount = amount
        self.description = description

class TransactionList:
    def __init__(self):
        self.List = []
        
    def add_transaction(self, date, amount, description):
        self.List.append(Transact(date, amount, description))
           
    def transacPie(self, cat_list):
        categories = ["Housing", "Food", "Phone", "Entertainment", "Travel", "Car", "Other", "Health"]
        money = {}
        for category in categories:
            money[category] = 0
                
        for x in cat_list:
            check = False
            for category in categories:
                if category == x.description:
                    check = True
                    money[category] += abs(x.amount)
                    money[category] = round(money[category], 2)
            if check is False:
                money['Other'] += abs(x.amount)
                money['Other'] = round(money['Other'], 2)    
        
        money2 = [ v for v in money.values() ]
            
        with open('static/money.js', 'w') as out_file:
            out_file.write('var data_transac = %s;\n' % json.dumps(money2))

    def categoryPie(self, catList):
        dict1 = {}
        list1 = []
        x = 0
        for cat in catList:
            dict1['Date'] = catList[x].date
            dict1['Amount'] = catList[x].amount
            dict1['Descpription'] = catList[x].description   
            list1.append(dict1)  
            x+=1                   
        
        with open('static/categoryPie.js', 'w') as out_file:
            out_file.write('var data_category = %s;\n' % json.dumps(list1))
                                     
    def findhistory(self):
        filename = 'data.txt'
        out = open(filename, 'r')
        string1 = out.readline().strip("\n")
        string2 = out.readline().strip("\n")
        date_object = datetime.strptime(string1, '%m/%d/%Y').date()
        date_object1 = datetime.strptime(string2, '%m/%d/%Y').date()
        newList=[]
        for x in self.List:
            string3 = x.date
            date_object2 = datetime.strptime(string3, '%d/%m/%Y').date()
            if date_object2 < date_object1:
                if date_object2 > date_object:
                    newList.append(x)
        self.transacPie(newList)
        self.categoryPie(newList)
        return newList

    def allHistory(self):
        cat_list = self.List
        self.transacPie(cat_list)
        self.categoryPie(cat_list)
        return self.List        

    def monthlyExpenditureData(self):
        mainList = []
        today = date.today()
        today = today.replace(day=1)
        d2 = today - dateutil.relativedelta.relativedelta(months=12)

        for x in self.List:
            date_object = datetime.strptime(x.date, '%d/%m/%Y').date()
            if d2 < date_object:
                if x.amount < 0:
                    list1 = []                   
                    list1.append(date_object)
                    list1.append(x.amount)
                    mainList.append(list1)
                    
        d = defaultdict(int)
        for x, val in mainList:
            d[x.strftime('%Y-%m')] += val
            d[x.strftime('%Y-%m')] = round(d[x.strftime('%Y-%m')], 2)    
        monthlyExp = list(map(list, d.items()))
                
        mE = []
        for x, y in monthlyExp:
            mE.append(abs(y))

        monthNames = self.monthLabels()            
            
        with open('static/data_me.js', 'w') as out_file:
            out_file.write('var data_exp = %s;\n' % json.dumps(mE))
            out_file.write('var months_mE = %s;\n' % json.dumps(monthNames))
            
    def accountBalData(self):
        mainList = []
        today = date.today()
        today = today.replace(day=1)
        d2 = today - dateutil.relativedelta.relativedelta(months=12)

        for x in self.List:
            date_object = datetime.strptime(x.date, '%d/%m/%Y').date()
            if d2 < date_object:
                list1 = []                   
                list1.append(date_object)
                list1.append(x.amount)
                mainList.append(list1)
                    
        d = defaultdict(int)
        for x, val in mainList:
            d[x.strftime('%Y-%m')] += val
            d[x.strftime('%Y-%m')] = round(d[x.strftime('%Y-%m')], 2)    
        monthlyExp = list(map(list, d.items()))
                
        aB1 = []
        for x, y in monthlyExp:
            aB1.append(y)
        aB = []
        num = 0
        for i in aB1:
            num += i
            aB.append(num)
                    
        monthNames = self.monthLabels()

        with open('static/data_aB.js', 'w') as out_file:
            out_file.write('var data_aB = %s;\n' % json.dumps(aB))
            out_file.write('var months_aB = %s;\n' % json.dumps(monthNames))  
                  
    def monthLabels(self):
        months = []
        currentMonth = datetime.now().month
        currentMonth = int(currentMonth)
        while currentMonth in range(13):
            months.append(calendar.month_abbr[currentMonth])
            currentMonth+=1
        i = 1
        while len(months) != 13:
            months.append(calendar.month_abbr[i])
            i+= 1
        return months
    def newCat(self):
        categories = ["Housing", "Food", "Phone", "Entertainment", "Travel", "Car", "Other", "Health"]
        today = date.today()
        d2 = today - dateutil.relativedelta.relativedelta(months=12)

        money = {}
        for category in categories:
            money[category] = 0
                
        for x in self.List:
            date_object = datetime.strptime(x.date, '%d/%m/%Y').date()
            if d2 < date_object:
                check = False
                for category in categories:
                    if category == x.description:
                        check = True
                        money[category] += abs(x.amount)
                        money[category] = round(money[category], 2)
                    if check is False:
                        money['Other'] += abs(x.amount)
                        money['Other'] = round(money['Other'], 2)    
        
        return money                      


class ReminderList:
    def __init__(self):
        self.List = []
    def add_reminder(self, date1, amount, description):
        error = None
        today = date.today()
        date_object = datetime.strptime(date1, '%m/%d/%Y').date()
        check = True
        for x in self.List:
            if x[0] == date1 and x.amount == amount and x.description == description:
                check = False
                error = "Reminder already exists"
                break
        if today <= date_object and check is True:
            con = create_connection()
            with con:
                values = (date1, amount, description)
                insert_rem(con, values)
                self.List = list_of_rem(con)

        elif date_object < today:
            error = "Date invalid"
            
        return error
            
    def removeReminder(self, date, amount, description):
        con = create_connection()
        with con:
            values = (date, amount, description)
            removeReminder(con, values)
            
    def allReminders(self):
        con = create_connection()
        with con:
            self.List = list_of_rem(con)    
            return self.List


    
   

payment_reminders = ReminderList()

                
transaction_history = TransactionList()
transaction_history.add_transaction("1/4/2020", 300, "Work")      
transaction_history.add_transaction("1/4/2019", 300, "Work")  

transaction_history.add_transaction("5/4/2019", -40.56, "Phone")
transaction_history.add_transaction("7/4/2019", -17.54, "Health")
transaction_history.add_transaction("21/4/2019", -17.54, "Health")
transaction_history.add_transaction("14/4/2019", 400, "Work")
transaction_history.add_transaction("16/4/2019", -14.53, "Food")
transaction_history.add_transaction("22/4/2019", -9.99, "Food")
transaction_history.add_transaction("22/4/2019", -15.00, "Entertainment")
transaction_history.add_transaction("25/4/2019", -30.00, "Other")
transaction_history.add_transaction("28/4/2019", -27.05, "Food")

transaction_history.add_transaction("1/5/2019", 400, "Work")
transaction_history.add_transaction("1/5/2019", -21, "Food")
transaction_history.add_transaction("5/5/2019", -40.56, "Phone")
transaction_history.add_transaction("5/5/2019", -17.54, "Health")
transaction_history.add_transaction("19/5/2019", -17.54, "Health")
transaction_history.add_transaction("14/5/2019", 400, "Work")
transaction_history.add_transaction("14/5/2019", -20.44, "Entertainment")
transaction_history.add_transaction("14/5/2019", -12.30, "Food")
transaction_history.add_transaction("20/5/2019", -22.88, "Food")
transaction_history.add_transaction("22/5/2019", -13.00, "Other")
transaction_history.add_transaction("22/5/2019", -12.00, "Other")
transaction_history.add_transaction("22/5/2019", -5.00, "Other")
transaction_history.add_transaction("28/5/2019", -200, "Travel")
transaction_history.add_transaction("28/5/2019", -167, "Travel")
transaction_history.add_transaction("30/5/2019", -15.67, "Food")

transaction_history.add_transaction("1/6/2019", 400, "Work")
transaction_history.add_transaction("2/6/2019", -17.54, "Health")
transaction_history.add_transaction("5/6/2019", -40.56, "Phone")
transaction_history.add_transaction("7/6/2019", -32.00, "Food")
transaction_history.add_transaction("14/6/2019", 400, "Work")
transaction_history.add_transaction("16/6/2019", -17.54, "Health")
transaction_history.add_transaction("17/6/2019", -12.00, "Food")
transaction_history.add_transaction("24/6/2019", -13.44, "Food")
transaction_history.add_transaction("24/6/2019", -30.00, "Gift")

transaction_history.add_transaction("1/7/2019", 400, "Work")
transaction_history.add_transaction("5/7/2019", -40.56, "Phone")
transaction_history.add_transaction("5/7/2019", -10.99, "Food")
transaction_history.add_transaction("7/7/2019", -17.54, "Health")
transaction_history.add_transaction("10/7/2019", -13.44, "Food")
transaction_history.add_transaction("14/7/2019", 400, "Work")
transaction_history.add_transaction("21/7/2019", -17.54, "Health")
transaction_history.add_transaction("22/7/2019", -23.88, "Food")
transaction_history.add_transaction("26/7/2019", -110.64, "Other")
transaction_history.add_transaction("27/7/2019", -30.00, "Entertainment")
transaction_history.add_transaction("30/7/2019", -17.54, "Health")

transaction_history.add_transaction("1/8/2019", 400, "Work")
transaction_history.add_transaction("1/8/2019", -22, "Food")
transaction_history.add_transaction("5/8/2019", -40.56, "Phone")
transaction_history.add_transaction("13/8/2019", -17.54, "Health")
transaction_history.add_transaction("14/8/2019", 400, "Work")
transaction_history.add_transaction("14/8/2019", -14.30, "Food")
transaction_history.add_transaction("14/8/2019", -30.00, "Entertainment")
transaction_history.add_transaction("22/8/2019", -15, "Entertainment")
transaction_history.add_transaction("26/8/2019", -22.88, "Food")
transaction_history.add_transaction("27/8/2019", -17.54, "Health")
transaction_history.add_transaction("28/8/2019", -399, "Travel")
transaction_history.add_transaction("28/8/2019", -155, "Travel")
transaction_history.add_transaction("30/8/2019", -18.67, "Food")

transaction_history.add_transaction("1/9/2019", 400, "Work")
transaction_history.add_transaction("3/9/2019", -11.00, "Food")
transaction_history.add_transaction("5/9/2019", -40.56, "Phone")
transaction_history.add_transaction("10/9/2019", -17.54, "Health")
transaction_history.add_transaction("14/9/2019", 400, "Work")
transaction_history.add_transaction("16/9/2019", -13.90, "Food")
transaction_history.add_transaction("20/9/2019", -42.00, "Other")
transaction_history.add_transaction("20/9/2019", -22.88, "Gift")
transaction_history.add_transaction("24/9/2019", -8.00, "Food")
transaction_history.add_transaction("24/9/2019", -17.54, "Health")
transaction_history.add_transaction("29/9/2019", -16.44, "Food")

transaction_history.add_transaction("1/10/2019", 400, "Work")
transaction_history.add_transaction("3/10/2019", -11.00, "Food")
transaction_history.add_transaction("5/10/2019", -40.56, "Phone")
transaction_history.add_transaction("10/10/2019", -17.54, "Health")
transaction_history.add_transaction("14/10/2019", 400, "Work")
transaction_history.add_transaction("16/10/2019", -13.90, "Food")
transaction_history.add_transaction("20/10/2019", -42.00, "Other")
transaction_history.add_transaction("20/10/2019", -22.88, "Gift")
transaction_history.add_transaction("24/10/2019", -8.00, "Food")
transaction_history.add_transaction("24/10/2019", -17.54, "Health")
transaction_history.add_transaction("29/10/2019", -16.44, "Food")

transaction_history.add_transaction("1/11/2019", 400, "Work")
transaction_history.add_transaction("3/11/2019", -11.00, "Food")
transaction_history.add_transaction("5/11/2019", -40.56, "Phone")
transaction_history.add_transaction("10/11/2019", -17.54, "Health")
transaction_history.add_transaction("14/11/2019", 400, "Work")
transaction_history.add_transaction("16/11/2019", -13.90, "Food")
transaction_history.add_transaction("20/11/2019", -42.00, "Other")
transaction_history.add_transaction("20/11/2019", -22.88, "Gift")
transaction_history.add_transaction("24/11/2019", -8.00, "Food")
transaction_history.add_transaction("24/11/2019", -17.54, "Health")
transaction_history.add_transaction("29/11/2019", -16.44, "Food")

transaction_history.add_transaction("1/12/2019", 400, "Work")
transaction_history.add_transaction("3/12/2019", -11.00, "Food")
transaction_history.add_transaction("5/12/2019", -40.56, "Phone")
transaction_history.add_transaction("10/12/2019", -17.54, "Health")
transaction_history.add_transaction("14/12/2019", 400, "Work")
transaction_history.add_transaction("16/12/2019", -13.90, "Food")
transaction_history.add_transaction("20/12/2019", -42.00, "Other")
transaction_history.add_transaction("20/12/2019", -22.88, "Gift")
transaction_history.add_transaction("24/12/2019", -8.00, "Food")
transaction_history.add_transaction("24/12/2019", -17.54, "Health")
transaction_history.add_transaction("29/12/2019", -16.44, "Food")

transaction_history.add_transaction("1/1/2020", 400, "Work")
transaction_history.add_transaction("3/1/2020", -11.00, "Food")
transaction_history.add_transaction("5/1/2020", -40.56, "Phone")
transaction_history.add_transaction("10/1/2020", -17.54, "Health")
transaction_history.add_transaction("14/1/2020", 400, "Work")
transaction_history.add_transaction("16/1/2020", -13.90, "Food")
transaction_history.add_transaction("20/1/2020", -42.00, "Other")
transaction_history.add_transaction("20/1/2020", -22.88, "Gift")
transaction_history.add_transaction("24/1/2020", -8.00, "Food")
transaction_history.add_transaction("24/1/2020", -17.54, "Health")
transaction_history.add_transaction("29/1/2020", -16.44, "Food")

transaction_history.add_transaction("1/2/2020", 400, "Work")
transaction_history.add_transaction("3/2/2020", -11.00, "Food")
transaction_history.add_transaction("5/2/2020", -40.56, "Phone")
transaction_history.add_transaction("10/2/2020", -17.54, "Health")
transaction_history.add_transaction("14/2/2020", 400, "Work")
transaction_history.add_transaction("16/2/2020", -13.90, "Food")
transaction_history.add_transaction("20/2/2020", -42.00, "Other")
transaction_history.add_transaction("20/2/2020", -22.88, "Gift")
transaction_history.add_transaction("24/2/2020", -8.00, "Food")
transaction_history.add_transaction("24/2/2020", -17.54, "Health")
transaction_history.add_transaction("29/2/2020", -16.44, "Food")

transaction_history.add_transaction("1/3/2020", 400, "Work")
transaction_history.add_transaction("3/3/2020", -11.00, "Food")
transaction_history.add_transaction("5/3/2020", -40.56, "Phone")
transaction_history.add_transaction("10/3/2020", -17.54, "Health")
transaction_history.add_transaction("14/3/2020", 400, "Work")
transaction_history.add_transaction("16/3/2020", -13.90, "Food")
transaction_history.add_transaction("20/3/2020", -42.00, "Other")
transaction_history.add_transaction("20/3/2020", -22.88, "Gift")
transaction_history.add_transaction("24/3/2020", -8.00, "Food")
transaction_history.add_transaction("24/3/2020", -17.54, "Health")
transaction_history.add_transaction("29/3/2020", -16.44, "Food")

transaction_history.add_transaction("1/4/2020", 400, "Work")
transaction_history.add_transaction("3/4/2020", -11.00, "Food")
transaction_history.add_transaction("5/4/2020", -40.56, "Phone")
transaction_history.add_transaction("10/4/2020", -17.54, "Health")
transaction_history.add_transaction("14/4/2020", 400, "Work")
transaction_history.add_transaction("16/4/2020", -13.90, "Food")
transaction_history.add_transaction("20/4/2020", -42.00, "Other")
transaction_history.add_transaction("20/4/2020", -22.88, "Gift")
transaction_history.add_transaction("24/4/2020", -8.00, "Food")
transaction_history.add_transaction("24/4/2020", -17.54, "Health")
transaction_history.add_transaction("29/4/2020", -16.44, "Food")
