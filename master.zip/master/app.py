from flask import Flask, render_template, redirect, url_for, request
from backend import *
from datetime import datetime
import sqlite3
from database import *
app = Flask(__name__)

filename = 'data.txt'


@app.route('/')
def home():
    return render_template('Home.html')


@app.route('/Login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'admin' or request.form['password'] != 'admin':
            error = 'Invalid Credentials. Please try again.'
        else:
            return redirect(url_for('profile'))
    return render_template('Login.html', error=error)


@app.route('/Transaction_history')
def profile():
    transaction_history.monthlyExpenditureData()
    transaction_history.accountBalData()
    return render_template('Transaction_history.html')


@app.route('/Expenditure', methods=['GET','POST'])
def expenditure():
    error = None
    if request.method == 'POST':
        date = request.form['date']
        date1 = request.form['date1']
        out = open(filename, 'w')
        out.write(date + '\n')
        out.write(date1 + '\n')
        out.close()
        trans_list = transaction_history.findhistory()
        categories = transaction_history.newCat()
        return render_template('Expenditure.html', trans_list=trans_list, categories = categories)
    
    else:
        trans_list = transaction_history.allHistory() 
        categories = transaction_history.newCat()       
        return render_template('Expenditure.html', trans_list=trans_list, categories = categories)





@app.route('/Offers')
def offers():
    return render_template('Offers.html')


@app.route('/Payment_reminders', methods=['GET','POST', 'DELETE'])
def reminder():
    error = None
    remin_list = payment_reminders.allReminders()     
    if request.method == 'POST':
        date = request.form['date']
        amount = request.form['amount']
        amount = float(amount) * -1
        description = request.form['description']
        error = payment_reminders.add_reminder(date, amount, description)
        remin_list = payment_reminders.allReminders()
        return render_template('Payment_reminders.html', remin_list=remin_list, error = error)  
    elif request.method == 'DELETE':
        date = request.form['d1']
        amount = request.form['a1']
        description = request.form['d2']
        payment_reminders.removeReminder(date, amount, description)
        remin_list = payment_reminders.allReminders()
        return render_template('Payment_reminders.html', remin_list=remin_list, error = error)              
    else:        
        return render_template('Payment_reminders.html', remin_list=remin_list, error = error)   
    


    


@app.route('/Projections')
def projections():
    return render_template('Projections.html')


if __name__ == '__main__':
    app.run(host='127.0.0.1', port = 8000, debug=True)
