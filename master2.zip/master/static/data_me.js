var data_exp = [172.21, 564.93, 163.08, 282.13, 752.49, 189.86, 189.86, 189.86, 189.86, 189.86, 189.86, 189.86, 189.86];
var months_mE = ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr"];
