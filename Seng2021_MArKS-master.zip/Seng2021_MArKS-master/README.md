# Seng2021_MArKS

Abhyudit Gupta   z5196145
Kshitiz Saini    z5228933
Malavika Thakore z5258106
Sruti Desai      z5260319


Brief Introduction to problem: The objective of this application is to ensure customers have the ability to maximise the benefits reaped from the wide range of services Macquarie bank has on offer. Currently, customers are limited with the way their transaction data is analysed and displayed and there is no existing platform that personnalises available schemes and tips. To ensure MQ banking services align with customer wants and they are thus able to maximise savings/minimise expenditure, Bankquire have developed algorithms that will prove to enhance MQ services .





Deliverable-1 : Contents: Problem Statement, Features, User Stories, Low fidelity, High fidelity


Deliverable-2 : PART1: List of webstacks used, component diagram, choice of language with justification and comparison, machine requriments                         and summary
                PART2: updated list of user stories, sequence diagrams in respect to the use cases
