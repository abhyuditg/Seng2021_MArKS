from flask import Flask, render_template, redirect, url_for, request
from backend import *
from backend2 import *
from datetime import datetime
app = Flask(__name__)

filename = 'data.txt'


@app.route('/')
def home():
    return render_template('Home.html')


@app.route('/Login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'analise_roberts_1' or request.form['password'] != 'analise123':
            error = 'Invalid Credentials. Please try again.'
        else:
            return redirect(url_for('profile'))
    return render_template('Login.html', error=error)


@app.route('/Transaction_history')
def profile():
    return render_template('Transaction_history.html')


@app.route('/Expenditure', methods=['GET','POST'])
def expenditure():
    error = None

    if request.method == 'POST':
        date = request.form['date']
        date1 = request.form['date1']
        out = open(filename, 'w')
        out.write(date + '\n')
        out.write(date1 + '\n')
        out.close()
        trans_list = findhistory()
        return render_template('Expenditure.html', trans_list=trans_list)
    return render_template('Expenditure.html')


def findhistory():
    filename = 'data.txt'
    out = open(filename, 'r')
    string1 = out.readline().strip("\n")
    string2 = out.readline().strip("\n")
    date_object = datetime.strptime(string1, '%m/%d/%Y').date()
    date_object1 = datetime.strptime(string2, '%m/%d/%Y').date()
    List=[]
    for x in transaction_history:
        string3 = x.date
        date_object2 = datetime.strptime(string3, '%d/%m/%Y').date()
        if date_object2 < date_object1:
            if date_object2 > date_object:
                List.append(x)
    return List


@app.route('/Offers')
def offers():
    return render_template('Offers.html')


@app.route('/Payment_reminders', methods=['GET','POST'])
def reminder():
    error = None
    remin_list = Reminders
    if request.method == 'POST':
        date = request.form['date']
        amount = request.form['amount']
        amount = int(amount) * -1
        description = request.form['description']
        r1 = Reminder(date, amount, description)
        x = 0
        for obj in remin_list:
            if obj.date == r1.date and obj.description == r1.description and obj.amount == r1.amount:
                x = 1
        if x == 0:
            remin_list.append(r1)
        return render_template('Payment_reminders.html', remin_list=remin_list)
    return render_template('Payment_reminders.html', remin_list=Reminders)


@app.route('/Projections')
def projections():
    return render_template('Projections.html')


if __name__ == '__main__':
    app.run(debug=True)
